package clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GestionBD {
	private Connection con;
	private Statement st;

	public GestionBD() {
		super();
		String cadenaConexion = "jdbc:mysql://localhost:3306/SUPERMERCADO";
		String user = "root";
		String pass = "cursocurso";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(cadenaConexion, user, pass);
			st = con.createStatement();
		} catch (ClassNotFoundException e) {
			System.out.println("No se ha encontrado el driver para MySQL");
		} catch (SQLException e) {
			System.out.println("No se ha podido conectar con la base de datos");
			System.out.println(e.getMessage());
			con = null;
		}
	}

	public void desconectar() {
		try {
			if (!(con == null))
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ResultSet productosCategoria(String idCategoria) {
		ResultSet rs;

		try {
			rs = st.executeQuery("SELECT * FROM PRODUCTO WHERE idCategoria = " + idCategoria);

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL");
			rs = null;
		}

		return rs;
	}

	public ResultSet productosNombre(String nombre) {
		// Permite una b�squeda por contenido del nombre utilizando
		// el operador LIKE.
		ResultSet rs;

		try {
			rs = st.executeQuery("SELECT * FROM PRODUCTO WHERE NOMBRE LIKE '%" + nombre + "%'");

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL");
			rs = null;
		}

		return rs;
	}

	public ResultSet pedidoCliente(String pedido) {
		// Permite una b�squeda por contenido del nombre utilizando
		// el operador LIKE.
		ResultSet rs;

		try {
			rs = st.executeQuery(
					"select pedido.idpedido,idcliente,precio,unidades,(precio*unidades)as total,fechapedido,fechaentrega from pedido inner join detalle on pedido.idpedido=detalle.idpedido where pedido.idpedido="
							+ pedido);

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL");
			rs = null;
		}

		return rs;
	}

	public ResultSet clientesPais(String pais) {
		ResultSet rs;

		try {
			rs = st.executeQuery("SELECT * FROM CLIENTE WHERE PAIS LIKE '%" + pais + "%'");

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL");
			rs = null;
		}

		return rs;
	}

	public boolean aumentarPrecio(String idProducto) {
		// Retorna true si la operaci�n se ha realizado.
		int a;
		try {
			con.setAutoCommit(false);
			a = st.executeUpdate("UPDATE PRODUCTO SET PRECIO = PRECIO*1.03 WHERE IDPRODUCTO=" + idProducto);
			System.out.println("N�mero de filas afectadas " + a);
			con.commit();

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL UPDATE");
			return false;
		}
		return true;
	}

	public boolean borrarPedido(String idPedido) {
		// Retorna true si la operaci�n se ha realizado.
		// Tendr�s que eliminar primero los detalles del pedido
		// y despu�s el pedido.
		// Engloba ambas operaciones en la misma transacci�n.
		try {
			con.setAutoCommit(false);
			int a = st.executeUpdate("DELETE FROM DETALLE WHERE IDPEDIDO =" + idPedido);
			int b = st.executeUpdate("DELETE FROM PEDIDO WHERE IDPEDIDO=" + idPedido);
			System.out.println("N�mero de detalles eliminados" + a);
			System.out.println("N�mero de pedidos eliminados" + b);
			con.commit();

		} catch (SQLException e) {
			System.out.println("No se ha podido ejecutar la sentencia SQL UPDATE");
			return false;
		}
		return true;
	}
}